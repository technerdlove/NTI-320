#!/bin/bash
/usr/bin/hello.c
exit 0;
